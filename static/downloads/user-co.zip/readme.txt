## 画像の利用について

イラストレーションについては、SmartHR社、またはSmartHR社から委託された業務に関してのみ利用可能です。
イラストレーションの著作権などを譲渡、放棄したものではありませんのでご注意ください。

その他詳細については以下のページをご参照ください。
https://smarthr.design/basics/illustration/


---

SmartHR Design System
https://smarthr.design
