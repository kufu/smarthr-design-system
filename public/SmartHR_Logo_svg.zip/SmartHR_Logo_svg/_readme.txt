SmartHR ロゴ 

SmartHRのロゴに関しては、株式会社SmartHRまたは当社にその利用を認めた権利者が著作権などの知的財産権、使用権その他の権利を有しています。
使用する場合は、以下のガイドラインに準じて使用してください。
【ロゴ|SmartHR Design System】 https://smarthr.design/basics/logos/

お問い合わせ先
株式会社SmartHR　pr@smarthr.co.jp